import datetime
import socket
import cv2
import numpy
from queue import Queue
from _thread import *
import serial
import time
import socketserver
import threading
import json
import pymysql

py_serial = serial.Serial(port='COM7', baudrate=9600)

con = pymysql.connect(host='localhost', user='root', password='201618!@', db='car_number_db', charset='utf8')
cur = con.cursor()

enclosure_queue = Queue()  #요소를 추가할 떄 put(), 제거할 때 get()

def Threaded(client_socket, addr, queue):
    print("연결 주소 : ", addr[0], "-", addr[1])
    while True:
        try:
            data = client_socket.recv(1024)
            # print(data)
            if len(bytes(data).decode()) == 4:
                print(bytes(data).decode())
                sql = "SELECT * FROM "
                x = "car_number_db.car_info"
                cur.execute(sql + x)
                db_data = list(cur.fetchall())
                # print(data)
                for i in db_data:
                    if i[0] == bytes(data).decode():
                        py_serial.write("re".encode())
                    else:
                        pass
            if len(bytes(data).decode()) == 5:
                print(bytes(data).decode())
                sql = "SELECT * FROM "
                x = "car_number_db.car_info"
                cur.execute(sql + x)
                db_data = list(cur.fetchall())
                # print(data)
                for i in db_data:
                    if i[0] == bytes(data).decode()[1:5]:
                        py_serial.write("re".encode())
                    else:
                        pass
            if not data:
                print("연결해제 ", addr[0], "-", addr[1])
                break
            string_data = queue.get()
            client_socket.send(str(len(string_data)).ljust(16).encode())  #16칸으로 맞춘다(규격)
            client_socket.send(string_data)

        except Exception as e:
            print("Threaded error", e)
            break
        # command = input("tx data : ")
        # py_serial.write(command.encode())
        # time.sleep(0.1)
        # read_adu = py_serial.readline().decode()
        # print(read_adu)
    client_socket.close()

count = 0

def Webcam(queue):  #커메라에서 무한으로 이미지를 캡쳐해서 threaded로 보내기
    global count
    capture = cv2.VideoCapture(0)  #카메라 소스
    while True:
        ret, frame = capture.read()  #하나 하나의 프레임을 읽어들임(튜플 형태)
        if ret == False:
            continue
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]  #영상 형태(ex-4k, 파노라마 등등)
        result, imgencode = cv2.imencode('.jpg', frame, encode_param)
        #imencode : image를 encode 해주는 함수
        # 확장자/소스/파라미터 -> jpg확장자/JPEG_QUALITY/90

        #imgencode의 타입이 이미 numpy.array 형태이므로 data 생략 가능
        data = numpy.array(imgencode)
        # print(data.shape)  #데이터의 모양(벡터 형태)
        # string_data = data.tostring()
        bytes_data = data.tobytes()  #바이너리 데이터로 변환

        # print(imgencode)
        # print(type(imgencode))
        # print(data)
        # print(string_data)
        # print(bytes_data)
        if count == 0:
            # print(data.shape)
            # print(bytes_data)
            for i in bytes_data:  #카메라는 rgv값이라는 것을 알 수 있다.
                # print(i, '\n')
                count += 1
        # print(count)


        queue.put(bytes_data)
        cv2.imshow('SERVER_CAM', frame)

        key = cv2.waitKey(1)
        if key == 27:
            break

car_number = ""

def Arduino():
    global car_number
    while True:
        # command = input("tx data : ")
        # py_serial.write(command.encode())
        # time.sleep(0.1)
        # read_adu = py_serial.read_all().decode()
        read_adu = py_serial.readline().decode()
        read_adu = read_adu.replace("\n", "")
        read_adu = read_adu.replace("\r", "")
        # print(read_adu)
        if read_adu == "*":
            print("강제 오픈")
            py_serial.write("re".encode())
        elif read_adu == "#":
            if len(car_number) == 4:
                Registration()
                print("차량 등록 완료")
            else:
                print("차량 번호 자릿수가 맞지 않음")
                car_number = ""
                pass
        else:
            car_number = car_number + read_adu
            print(car_number)
            # print(len(car_number))

now = datetime.datetime.now().replace(microsecond=0)

def Registration():
    global now
    global car_number
    sql = "SELECT * FROM "
    x = "car_number_db.car_info"
    cur.execute(sql + x)
    # data = list(cur.fetchall())
    # print(data)
    sql = 'INSERT INTO car_info VALUES(%s,%s)'
    val = [(car_number, now)]
    try:
        cur.executemany(sql, val)
        con.commit()
    except Exception as ex:
        print('Registration', type(ex), ex)
    print("DB 저장 완료")
    car_number = ""


HOST = '192.168.0.11'
# HOST = '192.168.0.9' # 서버의 ip를 열음. (이 서버의 ip로 클라이언트가 접속을 해야 한다), 그전에 ping을 먼저 확인하도록.
PORT = 9900

server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
server_socket.bind((HOST, PORT))

server_socket.listen()
print("server on")
start_new_thread(Webcam, (enclosure_queue,))
# start_new_thread(Arduino, ())

while True:
    try:
        print("클라이언트 접속 대기 while 문")
        client_socket, addr = server_socket.accept()
        start_new_thread(Threaded, (client_socket, addr, enclosure_queue,))
        start_new_thread(Arduino, ())
    except:
        pass



















































server_socket.close()
