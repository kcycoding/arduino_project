-- Drop database car_number_db;
CREATE database car_number_db;
use car_number_db;

CREATE TABLE car_info -- 차량 번호 정보
(car_id char(15) NOT NULL primary key, -- 차량번호
Entry_time char(15) -- 집입시간
)
