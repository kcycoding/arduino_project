import socket
from tkinter import *  # Tkinter
from PIL import ImageTk
from PIL import Image  # Pillow
import cv2  # OpenCV
import ctypes
import numpy as np
import threading
import time
import pandas as pd
import pytesseract
from queue import Queue

MessageBox = ctypes.windll.user32.MessageBoxW

pytesseract.pytesseract.tesseract_cmd = "C:\\Program Files\\Tesseract-OCR\\tesseract.exe"

enclosure_queue = Queue()

def recvall(sock, count):
    buf = b''
    while count:
        newbuf = sock.recv(count)
        # print(len(newbuf), ":buffsize", newbuf, "newbuf_data")
        if not newbuf:
            return None
        buf += newbuf
        count -= len(newbuf)

    return buf


HOST = '192.168.0.11'
PORT = 9900
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

data1 = 0
capture = cv2.VideoCapture(0)


def message():
    global data1
    while True:
        message = '1'
        client_socket.send(message.encode())
        length = recvall(client_socket, 16)
        stringData = recvall(client_socket, int(length))
        data = np.frombuffer(stringData, dtype='uint8')
        data1 = cv2.imdecode(data, 1)

thread_ing = threading.Thread(target=message)
thread_ing.daemon = True
thread_ing.start()


class Show():
    def default(self):
        frame = None
        global data1

        frame = data1

        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))  # Image 객체로 변환
        imgtk = ImageTk.PhotoImage(image=img)  # ImageTk 객체로 변환
        lbl1.imgtk = imgtk
        lbl1.configure(image=imgtk)


    def Client_Cam(self):
        global capture
        ret, frame2 = capture.read()

        frame2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2RGB)
        img2 = Image.fromarray(frame2)  # Image 객체로 변환
        imgtk2 = ImageTk.PhotoImage(image=img2)  # ImageTk 객체로 변환
        lbl2.imgtk2 = imgtk2
        lbl2.configure(image=imgtk2)


    def start(self):
        self.default()
        self.Client_Cam()
        lbl1.after(10, self.start)


def Capture_Video():
    # time.sleep(1)
    # client_socket.send("7777".encode())

    capture_list = []
    num_result = {}
    time_limit = time.time() + 4
    cap_img = 1
    while True:
        global capture
        ret, frame = capture.read()
        cap1 = frame
        capture_list.append(cap1)
        # img = Image.fromarray(cap1)
        # Number = f'{cap_img}.jpg'
        cv2.imwrite(f'{cap_img}.jpg', cap1)
        # print(capture_list)
        # print(len(capture_list))
        cap_img += 1
        if time.time() > time_limit:
            break
    # print(capture_list)
    print("결과 출력 중")
    for c in range(1, 110):
        box1 = []
        f_count = 0
        select = 0
        plate_width = 0

        Number = f'{c}.jpg'
        img = cv2.imread(Number, cv2.IMREAD_COLOR)
        copy_img = img.copy()
        img2 = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cv2.imwrite('gray.jpg', img2)
        blur = cv2.GaussianBlur(img2, (3, 3), 0)
        cv2.imwrite('blur.jpg', blur)
        canny = cv2.Canny(blur, 120, 120)
        cv2.imwrite('canny.jpg', canny)
        contours, hierarchy = cv2.findContours(canny, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        for i in range(len(contours)):
            cnt = contours[i]
            area = cv2.contourArea(cnt)
            x, y, w, h = cv2.boundingRect(cnt)  # boundingRect(Straight Bounding Rectangle) : 물체의 회전은 고려하지 않은 사각형
            # minAreaRect(Rotated Rectangle) : 물체의 회전을 고려한 사각형
            rect_area = w * h  # area size
            aspect_ratio = float(w) / h  # ratio = width/height

            if (aspect_ratio >= 0.2) and (aspect_ratio <= 1.0) and (rect_area >= 100) and (rect_area <= 700):
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 1)
                box1.append(cv2.boundingRect(cnt))

        for i in range(len(box1)):  ##Buble Sort on python
            for j in range(len(box1) - (i + 1)):
                if box1[j][0] > box1[j + 1][0]:
                    temp = box1[j]
                    box1[j] = box1[j + 1]
                    box1[j + 1] = temp
        # print(box1)
        # print(len(box1))

        for m in range(len(box1)):
            count = 0
            for n in range(m + 1, (len(box1) - 1)):
                delta_x = abs(box1[n + 1][0] - box1[m][0])  # abs : 절대값
                if delta_x > 150:
                    break
                delta_y = abs(box1[n + 1][1] - box1[m][1])
                if delta_x == 0:
                    delta_x = 1
                if delta_y == 0:
                    delta_y = 1
                gradient = float(delta_y) / float(delta_x)
                if gradient < 0.25:
                    count = count + 1
            # measure number plate size
            if count > f_count:
                select = m
                f_count = count;
                plate_width = delta_x
        cv2.imwrite('snake.jpg', img)

        try:
            number_plate = copy_img[box1[select][1] - 10:box1[select][3] + box1[select][1] + 20,
                           box1[select][0] - 10:140 + box1[select][0]]
            resize_plate = cv2.resize(number_plate, None, fx=1.8, fy=1.8, interpolation=cv2.INTER_CUBIC + cv2.INTER_LINEAR)
            plate_gray = cv2.cvtColor(resize_plate, cv2.COLOR_BGR2GRAY)
            ret, th_plate = cv2.threshold(plate_gray, 150, 255, cv2.THRESH_BINARY)  # 숫자 굵기 설정
        except:
            pass

        cv2.imwrite('plate_th.jpg', th_plate)
        kernel = np.ones((3, 3), np.uint8)
        er_plate = cv2.erode(th_plate, kernel, iterations=1)
        er_invplate = er_plate
        cv2.imwrite('er_plate.jpg', er_invplate)
        result = pytesseract.image_to_string(Image.open('er_plate.jpg'), lang='kor', config='digits')
        result = result.replace(" ", "")
        result = result.replace("\n", "")
        print("결과 값 : ", result)
        if result in num_result:
            num_result[result] += 1
        else:
            num_result.setdefault(result)
            num_result[result] = 1
        # num_result.append(result)
    print("결과 출력 완료")
    for key in num_result.copy().keys():
        if key == "":
            del num_result[""]
    for key in num_result.copy().keys():
        if len(str(key)) != 4:
            del num_result[key]

    print(num_result)
    num_result_list = [k for k, v in num_result.items() if max(num_result.values()) == v]
    # num_result = ''.join(num_result)
    num_result_ = num_result_list[0]
    print("차량 번호 : ", num_result_)
    client_socket.send(num_result_.encode())
    time.sleep(1)



window = Tk()  # 인스턴스 생성
window.title("PARKING")  # 제목 표시줄 추가
window.geometry("1500x600+5+50")  # 지오메트리: 너비x높이+x좌표+y좌표
window.resizable(True, False)  # x축, y축 크기 조정 비활성화
window.configure(bg='azure')


lbl = Label(window, text="<차량 번호판 인식>", bg="azure", font=("돋움", 15, "bold"))
lbl.grid(row=0, column=0)  # 라벨 행, 열 배치

frm = Frame(window, bg="azure", width=1500, height=500)  # 프레임 너비, 높이 설정
frm.grid(row=1, column=0)  # 격자 행, 열 배치

lbl1 = Label(frm)
lbl1.place(x=5,y=30)

car = Button(window, width=5, text='저장', height=2, bg="white", command=Capture_Video)
car.place(x=1400, y=470)

lbl2 = Label(frm)
lbl2.place(x=700, y=30)
#################################버튼 ########################################

show = Show()
show.start()
window.mainloop()
